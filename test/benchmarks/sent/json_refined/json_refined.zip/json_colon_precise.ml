exception JSONEx of string 
type json = 
			| Num of int 
			| Str of int 
			| Obj of field 
and field = Pair of json * json 

type output  = ParseRes of (json) * (int list)
(*proj for Pair (json, int list)*)
let projl lp = 
	match lp with 
		| ParseRes (l, r) -> l
	
let projr lp = 
	match  lp with
	| ParseRes (l, r) -> r



let eq x1 y1 = true 

let raise ex = 
		let em = [] in 
		let z = 0 in 
		let defjson = Num z in 
		let defrem = em in  
		let resex = ParseRes (defjson,defrem) in 
		resex


let rec concat l1 l2 = 
match l1 with
    [] -> let resem = l2 in resem
  | x1::xs1 ->  let temp1 = concat xs1 l2 in
                let temp2 = x1::temp1 in 
                temp2





(*trims the white spaces using many1 ws/tab*)

let rec parse_spaces ls =
	match ls with 
	[] -> let em = [] in em
	| x :: xs -> 
		let thrty_two = 32 in 
		let eq_x_32 = eq x thrty_two in 
		if(eq_x_32) then 
			let trimmed = parse_spaces xs in 
			trimmed  
		else
			let rese = ls in 
			rese	




let parse_token (fwsp) (lst) (inparser) = 
	let em = [] in 
	let lst = concat lst em in 
	let lst' = fwsp lst in
	let lst'' = concat lst' em in 
	let res = inparser lst'' in 
	let l1 = projl res in 
	let l2 = projr res in 
	res  





let parse_num inp = 
	match inp with
	[] -> raise (JSONEx "Invalid number")
	| x :: xs ->
				(* let two = 2 in 
				let jsres = Num two in 	 
				 *)let jsres = Num x in 
	 			 let restoret = ParseRes (jsres, xs) in 
				restoret
 		


let parse_num_ref lnum = 
	let js = parse_token (parse_spaces) (lnum) (parse_num) in 
(* 	let rem = projr js in 
	let two = 2 in 
	let jsdummy = Num two in 
	let resjs = ParseRes (jsdummy, rem) in 
	resjs
 *)
 	js
let parse_colon ls = 
	match ls with 
	[] -> raise (JSONEx "Error parsing colon no input ")
	| x :: xs -> 
			let fifty_eight = 58 in 
			let eq_x_58 = eq x fifty_eight in 
			if (eq_x_58) 
			then 
				let colon_parse = Str x in
				(* let two = 2 in 
				let colon_parse = Str two in   
				 *)let resc = ParseRes (colon_parse, xs) in 
				resc
			else 
					(*uncomment this for neg*)
					(* let colon_parse = Str x in
					let resc = ParseRes (colon_parse, xs) in 
				resc
				 *)
			 	raise (JSONEx ("Error parsing colon found"))
 
let parse_colon_ref lls = 
	let colonres = parse_token (parse_spaces) (lls) (parse_colon) in 
	colonres 


(* let rec parse_field fls = 
	match fls with 
	[] -> raise (JSONEx "parsing empty field")
	| x :: xs -> 
		let key_n_r1 = parse_json_ref fls in 
		let key = projl key_n_r1 in 
		let rem1 = projr key_n_r1 in 
		let colon_n_r2 = parse_colon_ref rem1 in 
		let rem2 = projr colon_n_r2 in 
		let value_n_r3 = parse_json_ref rem2 in 
		let value = projl value_n_r3 in 
		let rem4 = projr value_n_r3 in 
		
		let f = Pair (key, value) in 
		let json4f = Obj f in 
		(* let em = [] in 
		let z = 0 in 
		let defjson = Num z in 
		 *)
		ParseRes (json4f, rem4)   


and  parse_json inlist = 
	match inlist with 
	[] -> 	raise (JSONEx "parsing empty")
	| x :: xs ->
		(*either parse a string, or parse a number *) 
		let one_twnty_three = 123 in 
		let eq_x_123 = eq x one_twnty_three in 
		if (eq_x_123) (*case {*) then 
			let  f = parse_field_ref xs in 
		 	let rem = projr f in 
		 	(match rem with (*test for terminal brace*)
		 		[] -> raise (JSONEx "End reached without terminal }")
		 		| y :: ys -> 
					let one_twnty_five = 125 in 
					let eq_x_125 = eq y one_twnty_five in 
		 			if (eq_x_125) then 
		 				f
		 			else 
  	 				  raise (JSONEx ("no termianl }")) )
		 			 		
		else
		   let numjson = parse_num_ref inlist in 
			numjson	  
 
 and parse_json_ref jinlist = 
 	let jsres = parse_token (parse_spaces) (jinlist) (parse_json) in 
 	jsres			
and parse_field_ref jflst = 
	let jsfield = parse_token (parse_spaces) (jflst) (parse_field) in 
	jsfield
 *)
(*the ws handled version*)

